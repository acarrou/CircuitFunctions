A Python library I created for my circuits class. I am still adding on a bunch of different functions to easily calculate circuit math. The only current dependency is numpy library.

Change Log
================

0.0.1 (9/14/2021)
-----------------
-First Release

